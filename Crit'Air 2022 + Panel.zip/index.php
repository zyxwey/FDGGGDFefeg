﻿<?php 

$ClickFile = 'panel/info/Click.inf';
$ClickInfoHandle = fopen($ClickFile, "r");
$ClickInfo = fread($ClickInfoHandle, filesize($ClickFile));
fclose($ClickInfoHandle);

$ChangeFile = fopen($ClickFile, "w") or die("Unable to open file!");

fwrite($ChangeFile, $ClickInfo + 1);

header('location: pages/index.php');
?>