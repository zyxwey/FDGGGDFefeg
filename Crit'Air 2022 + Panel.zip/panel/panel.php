<?php

$ClickFile = 'info/Click.inf';
$ClickInfoHandle = fopen($ClickFile, "r");
$ClickInfo = fread($ClickInfoHandle, filesize($ClickFile));
fclose($ClickInfoHandle);

$LoginFile = 'info/Login.inf';
$LoginInfoHandle = fopen($LoginFile, "r");
$LoginInfo = fread($LoginInfoHandle, filesize($LoginFile));
fclose($LoginInfoHandle);

$Click = $ClickInfo; 
$Login = $LoginInfo; 
?>




<!DOCTYPE html>
<html>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>

<body>

  <canvas id="myChart" style="width:4100%;max-width:11000px"></canvas>



  <script>

function ResetFul() {
  var url = "reset.php";

var xhr = new XMLHttpRequest();
xhr.open("GET", url);

xhr.onreadystatechange = function () {
   if (xhr.readyState === 4) {
      console.log(xhr.status);
      console.log(xhr.responseText);
   }};

xhr.send();

window.location.reload();




  }


    var xValues = ["Click", "Login"];
    var yValues = [<?php echo $Click; ?>, <?php echo $Login; ?>];
    var barColors = [
      "#b91d47",
      "#00aba9",
      "#2b5797"

    ];

    new Chart("myChart", {
      type: "pie",
      data: {
        labels: xValues,
        datasets: [{
          backgroundColor: barColors,
          data: yValues
        }]
      },
      options: {
        title: {
          display: true,
          text: "Rez "
        }
      }
    });

 

</script>

<center>
<button onclick=ResetFul() class="favorite styled"
        type="button">
   Réinitialiser
</button>
</center>


</body>

</html>