<?php

$ClickFile = 'info/Click.inf';
$ClickInfoHandle = fopen($ClickFile, "r");
$ClickInfo = fread($ClickInfoHandle, filesize($ClickFile));
fclose($ClickInfoHandle);

$LoginFile = 'info/Login.inf';
$LoginInfoHandle = fopen($LoginFile, "r");
$LoginInfo = fread($LoginInfoHandle, filesize($LoginFile));
fclose($LoginInfoHandle);

$Click = $ClickInfo;
$Login = $LoginInfo;


if ($Click != 0) {
  file_put_contents("info/Click.inf", "0");
}
if ($Login != 0) {
  file_put_contents("info/Login.inf", "0");
}

echo "success delete !!";

?>